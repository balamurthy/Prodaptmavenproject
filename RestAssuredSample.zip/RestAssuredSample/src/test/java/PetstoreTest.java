import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.*;

public class PetstoreTest {

    private static final String BASE_URL = "https://petstore.swagger.io/v2";
    private static long petId;

    @BeforeClass
    public void setup() {
        RestAssured.baseURI = BASE_URL;
    }

    @Test(priority = 1)
    public void addPet() {
        String petJson = "{ \"id\": 8888, \"name\": \"RexBala\", \"status\": \"available\" }";
        petId = 12345;

        given()
            .contentType(ContentType.JSON)
            .body(petJson)
        .when()
            .post("/pet")
        .then()
            .statusCode(200)
            .body("id", equalTo((int) petId))
            .body("name", equalTo("RexBala"))
            .body("status", equalTo("available"));
    }

    @Test(priority = 2)
    public void getPet() {
        given()
            .pathParam("petId", petId)
        .when()
            .get("/pet/{petId}")
        .then()
            .statusCode(200)
            .body("id", equalTo((int) petId))
            .body("name", equalTo("Rex"));
        System.out.println("Pet with ID " + petId + " retrieved successfully.");
    }
/*
    @Test(priority = 3)
    public void deletePet() {
        given()
            .pathParam("petId", petId)
        .when()
            .delete("/pet/{petId}")
        .then()
            .statusCode(200)
            .body("message", equalTo(String.valueOf(petId)));
    }

    
      @Test(priority = 4)
     
    public void verifyPetDeleted() {
        given()
            .pathParam("petId", petId)
        .when()
            .get("/pet/{petId}")
        .then()
            .statusCode(404);
    }
    */
}
